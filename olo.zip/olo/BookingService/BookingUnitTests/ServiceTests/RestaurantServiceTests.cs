using BookingService.Models;
using BookingService.Repositories.Interfaces;
using Moq;
using Services;
using System;
using Xunit;

namespace BookingUnitTests
{
    public class RestaurantServiceTests
    {
        public Mock<IRestaurantRepository> _restRepo = new();

        [Fact]
        public async void CreateRestaurant_WithValidFields_ReturnsRestaurantWithId()
        {
            // Arrange
            _restRepo.Setup(u => u.InsertRestaurant(It.IsAny<Restaurant>())).ReturnsAsync(new Restaurant {Name = "new", RestaurantId = 1 });
            var classUnderTest = new RestaurantService(_restRepo.Object);

            // Act
            var created = await classUnderTest.CreateRestaurant(new Restaurant { Name = "new"});

            // Assert
            Assert.Equal(1, created.RestaurantId);
            _restRepo.VerifyAll();
        }
    }
}
