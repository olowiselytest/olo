﻿using BookingService.Exceptions;
using BookingService.Models;
using System;
using System.Net;

namespace BookingService.Utils
{
    public class ExceptionHandlerUtil
    {
        public static ErrorDetails GetExceptionDetails(Exception ex)
        {
            if (ex is ScheduleException)
            {
                return new ErrorDetails { Code = (int)HttpStatusCode.BadRequest, Message = "Schedule was malformed" };
            }

            if (ex is ArgumentException)
            {
                var param = (ex as ArgumentException).ParamName;
                var message = "Malformed Request";

                if (!param.ToLower().Contains("id"))
                {
                    message = $"{param} is an unsupported value";
                }

                return new ErrorDetails { Code = (int)HttpStatusCode.BadRequest, Message = message};
            }

            if (ex is ArgumentNullException)
            {
                var param = (ex as ArgumentException).ParamName;
                return new ErrorDetails { Code = (int)HttpStatusCode.BadRequest, Message = $"{param} cannot be null"};
            }
            if (ex is TooManyBookingsException)
            {
                return new ErrorDetails { Code = (int)HttpStatusCode.BadRequest, Message = "Out of slots at this time" };
            }

            if (ex is NoReservationException)
            {
                return new ErrorDetails { Code = (int)HttpStatusCode.BadRequest, Message = "There are no reservations at this time" };
            }

            return new ErrorDetails { Code = (int)HttpStatusCode.InternalServerError, Message = "Something Went Wrong!"};
        }
    }
}
