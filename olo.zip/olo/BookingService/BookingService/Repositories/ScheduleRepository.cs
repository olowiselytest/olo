﻿using BookingService.Models;
using BookingService.Repositories.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookingService.Repositories
{
    public class ScheduleRepository : IScheduleRepository
    {
        private readonly IConfiguration _configuration;

        private const string ConnString = "Postgres_Conn_String";

        public ScheduleRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task InsertSchedule(Schedule schedule)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);
            connection.Open();
            using var transaction = connection.BeginTransaction(); // All or nothing schedule; using - transaction will automatically rollback

            // Was reading between copy, bulk insert, and just several inserts in the same transactions this is 
            // performant - didn't really dive in very deeply though. I'd want to research this more in a real setting. 
            foreach (var scheduleEntry in schedule.ScheduleDef)
            {
                await connection.ExecuteAsync("INSERT INTO Booking.Schedule (Time, RestaurantId, Seats, NumberOfTables) " +
                                              $"VALUES(CAST(@Time as Time), {schedule.RestaurantId}, @Seats, @NumberOfTables)", scheduleEntry);
            }

            transaction.Commit();
        }

        public async Task<int> GetPartySize(int scheduleId)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);

            return await connection.QuerySingleAsync<int>($"Select s.seats FROM Booking.Schedule s Where scheduleId = {scheduleId}");
        }

        public async Task<int> GetTotalTables(int scheduleId)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);

            return await connection.QuerySingleAsync<int>($"Select s.NumberOfTables FROM Booking.Schedule s Where scheduleId = {scheduleId}");
        }
    }
}
