﻿using BookingService.Models;
using BookingService.Repositories.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System.Threading.Tasks;

namespace BookingService.Repositories
{
    public class RestaurantRepository : IRestaurantRepository
    {
        private readonly IConfiguration _configuration;

        private const string ConnString = "Postgres_Conn_String";

        public RestaurantRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<Restaurant> InsertRestaurant(Restaurant restaurant)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);
            return await connection.QuerySingleAsync<Restaurant>("INSERT INTO Booking.Restaurant (Name) " +
                                                                 "VALUES(@Name) Returning *", restaurant);
        }
    }
}

