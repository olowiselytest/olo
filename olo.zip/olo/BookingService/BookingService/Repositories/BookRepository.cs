﻿using BookingService.Exceptions;
using BookingService.Models;
using BookingService.Repositories.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System.Threading.Tasks;

namespace BookingService.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly IConfiguration _configuration;

        private const string ConnString = "Postgres_Conn_String";

        public BookRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// way too much logic in here, messes with unit testing but....
        /// </summary>
        /// <param name="book"></param>
        /// <param name="guest"></param>
        /// <returns></returns>
        public async Task UpdateBooking(Book book, Guest guest)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);
            connection.Open();
            using var transaction = connection.BeginTransaction();

            //In addition to table-level locks, there are row - level locks,
            //which can be exclusive or shared locks.An exclusive row -
            //level lock on a specific row is automatically acquired when the
            //row is updated or deleted.The lock is held until the transaction commits or rolls back
            // FOR UPDATE ROW LOCKS
            var bookingDetails = await connection.QuerySingleOrDefaultAsync<BookingDetails>($"SELECT * FROM Booking.Booking_Details bd where bd.ScheduleId = {book.ScheduleId} FOR UPDATE");

            if (bookingDetails.TakenTables >= bookingDetails.TotalTables)
            {
                throw new TooManyBookingsException();
            }

            await connection.QuerySingleOrDefaultAsync<BookingDetails>($"UPDATE Booking.Booking_Details SET TakenTables = {bookingDetails.TakenTables + 1} WHERE ScheduleId = {bookingDetails.ScheduleId}");

            // This should not be in here....
            var insertedDetails = await connection.QuerySingleOrDefaultAsync<BookingDetails>($"INSERT INTO Booking.Guest (Email, Name, BookingId) VALUES (@Email, @Name, {bookingDetails.BookingId})", guest);

            transaction.Commit();
        }

        public async Task<int> InsertBooking(int scheduleId, int totalTables)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);

            return await connection.ExecuteAsync("INSERT INTO Booking.Booking_Details (ScheduleId, TotalTables, TakenTables) " +
                                              $"VALUES({scheduleId}, {totalTables}, {0})");
        }

        public async Task<int> GetBooking(int scheduleId)
        {
            using var connection = new NpgsqlConnection(_configuration[ConnString]);

            return await connection.QuerySingleOrDefaultAsync<int>($"Select * FROM Booking.Booking_Details s Where scheduleId = {scheduleId}");
        }
    }
}
