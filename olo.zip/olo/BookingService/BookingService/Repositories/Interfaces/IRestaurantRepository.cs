﻿using BookingService.Models;
using System.Threading.Tasks;

namespace BookingService.Repositories.Interfaces
{
    public interface IRestaurantRepository
    {
        Task<Restaurant> InsertRestaurant(Restaurant restaurant);
    }
}
