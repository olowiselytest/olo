﻿using BookingService.Models;
using System.Threading.Tasks;

namespace BookingService.Repositories.Interfaces
{
    public interface IScheduleRepository
    {
        Task<int> GetPartySize(int scheduleId);
        Task<int> GetTotalTables(int scheduleId);
        Task InsertSchedule(Schedule schedule);
    }
}
