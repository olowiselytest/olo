﻿using BookingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingService.Repositories.Interfaces
{
    public interface IBookRepository
    {
        Task<int> GetBooking(int scheduleId);
        Task<int> InsertBooking(int scheduleId, int totalTables);
        Task UpdateBooking(Book book, Guest guest);
    }
}
