﻿using AutoMapper;
using BookingService.Models;
using BookingService.Models.DataTransferObjects;
using BookingService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BookingService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [RequireHttps]
    public class RestaurantController : ControllerBase
    {
        private readonly IRestaurantService _restaurantService;
        private readonly IMapper _mapper;

        public RestaurantController(IRestaurantService restaurantService, IMapper mapper)
        {
            _restaurantService = restaurantService;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult<OutgoingRestaurantDTO>> Post(IncomingPostRestaurantDTO postRestaurant)
        {
            var restuarant = _mapper.Map<Restaurant>(postRestaurant);
            var result = await _restaurantService.CreateRestaurant(restuarant);
            var outgoingResult = _mapper.Map<OutgoingRestaurantDTO>(result);

            return outgoingResult; // if we don't want to return the created object Created() with location URI
        }
    }
}
