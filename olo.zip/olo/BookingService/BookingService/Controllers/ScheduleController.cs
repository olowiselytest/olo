﻿using AutoMapper;
using BookingService.Exceptions;
using BookingService.Models;
using BookingService.Models.DataTransferObjects;
using BookingService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BookingService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [RequireHttps]
    public class ScheduleController : ControllerBase
    {
        private readonly IScheduleService _scheduleService;
        private readonly IMapper _mapper;

        public ScheduleController(IScheduleService scheduleService, IMapper mapper)
        {
            _scheduleService = scheduleService;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult> Post(IncomingScheduleDTO postSchedule)
        {
            var schedule = _mapper.Map<Schedule>(postSchedule);
            await _scheduleService.CreateSchedule(schedule); // This might be an upsert on the service class, depending on biz requirements. 
           
            return Ok();
        }
    }
}
