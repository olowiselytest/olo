﻿using AutoMapper;
using BookingService.Models;
using BookingService.Models.DataTransferObjects;
using BookingService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BookingService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [RequireHttps]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;
        private readonly IMapper _mapper;

        public BookController(IBookService bookService, IMapper mapper)
        {
            _bookService = bookService;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult<OutgoingBookingConfirmationDTO>> Post(IncomingBookDTO postBook)
        {
            var booking = _mapper.Map<Book>(postBook);
            var guest = _mapper.Map<Guest>(postBook);
            await _bookService.CreateBooking(booking, guest);

            return Ok();
        }
    }
}
