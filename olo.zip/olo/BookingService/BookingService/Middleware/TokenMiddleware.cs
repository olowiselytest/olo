﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingService.Middleware
{
    public class TokenMiddleware
    {
        private readonly RequestDelegate _next;

        public TokenMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
           // var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

            //TODO - pulling token out, authorize it however.

            await _next(context);
        }
    }
}
