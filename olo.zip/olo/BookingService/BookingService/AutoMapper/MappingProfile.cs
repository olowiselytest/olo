﻿using AutoMapper;
using BookingService.Models;
using BookingService.Models.DataTransferObjects;

namespace BookingService.AutoMapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<IncomingPostRestaurantDTO, Restaurant>();
            CreateMap<Restaurant, OutgoingRestaurantDTO>();

            CreateMap<IncomingScheduleDTO, Schedule>();
            CreateMap<IncomingScheduleEntryDTO, ScheduleEntry>();

            CreateMap<IncomingBookDTO, Book>();
            CreateMap<IncomingBookDTO, Guest>();
        }
    }
}
