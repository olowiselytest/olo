﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingService.Exceptions
{
    public class TooManyBookingsException : Exception
    {
        public TooManyBookingsException() { }

        public TooManyBookingsException(string message)
            : base(message) { }
    }
}
