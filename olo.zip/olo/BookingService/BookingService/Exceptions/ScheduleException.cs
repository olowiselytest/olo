﻿using System;

namespace BookingService.Exceptions
{
    public class ScheduleException : Exception
    {
        public ScheduleException() { }

        public ScheduleException(string message)
            : base(message) { }
    }
}
