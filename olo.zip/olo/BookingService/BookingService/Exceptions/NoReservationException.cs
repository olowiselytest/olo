﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingService.Exceptions
{
    public class NoReservationException : Exception
    {
        public NoReservationException() { }

        public NoReservationException(string message)
            : base(message) { }
    }
}
