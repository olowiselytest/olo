using AutoMapper;
using BookingService.AutoMapper;
using BookingService.Middleware;
using BookingService.Models;
using BookingService.Repositories;
using BookingService.Repositories.Interfaces;
using BookingService.Services;
using BookingService.Services.Interfaces;
using BookingService.Utils;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Services;
using System.Threading.Tasks;

namespace BookingService
{
    public class Startup
    {
        private IConfiguration _configuration { get; set; }

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;

            // This would come from a keyvault or something of the like.
            _configuration["Postgres_Conn_String"] = "Host = localhost; Port = 5432; Database = booking; Username = postgres; Password = password"; 
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "BookingService", Version = "v1" });
            });

            SetUpSingletons(services);
            SetUpTransients(services);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
            });

            app.UseMiddleware(typeof(TokenMiddleware));
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();

            SetUpErrorHandling(app);

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        private static void SetUpErrorHandling(IApplicationBuilder app)
        {
            app.UseExceptionHandler(error =>
            {
                error.Run(async context =>
                {
                    ErrorDetails errorResponseDetails = GetErrorDetails(context);

                    //TODO Log Error; this is a central place for error logging code. 

                    await SendAppropriateErrorResponse(context, errorResponseDetails);
                });
            });
        }

        private static async Task SendAppropriateErrorResponse(HttpContext context, ErrorDetails errorResponseDetails)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = errorResponseDetails.Code;

            await context.Response.WriteAsync(JsonConvert.SerializeObject(new { error = errorResponseDetails.Message }));
        }

        private static ErrorDetails GetErrorDetails(HttpContext context)
        {
            var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
            var errorResponseDetails = ExceptionHandlerUtil.GetExceptionDetails(exceptionHandlerPathFeature.Error);
            return errorResponseDetails;
        }

        private void SetUpTransients(IServiceCollection services)
        {
            services.AddTransient<IRestaurantService, RestaurantService>();
            services.AddTransient<IRestaurantRepository, RestaurantRepository>();
            services.AddTransient<IScheduleService, ScheduleService>();
            services.AddTransient<IScheduleRepository, ScheduleRepository>();
            services.AddTransient<IBookService, BookService>();
            services.AddTransient<IBookRepository, BookRepository>();
        }

        private void SetUpSingletons(IServiceCollection services)
        {
            // SetUp AutoMapper
            var mapper = ConfigureAutoMapper();
            services.AddSingleton(mapper);
            services.AddSingleton(_configuration);
        }

        private static IMapper ConfigureAutoMapper()
        {
            var mapperConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });

            var mapper = mapperConfig.CreateMapper();

            return mapper;
        }
    }
}