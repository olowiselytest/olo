﻿using BookingService.Exceptions;
using BookingService.Models;
using BookingService.Repositories.Interfaces;
using BookingService.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace Services
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;
        private readonly IScheduleRepository _scheduleRepository;

        public BookService(IBookRepository bookRepository, IScheduleRepository scheduleRepository)
        {
            _bookRepository = bookRepository;
            _scheduleRepository = scheduleRepository;
        }

        public async Task CreateBooking(Book booking, Guest guest)
        {
            // Exception if doesn't exist, unhandled the responsibility is client side to sent the appropriate
            // scheduleID that corresponds with time and party size. 
            var partySize = await _scheduleRepository.GetPartySize(booking.ScheduleId);
            var totalTables = await _scheduleRepository.GetPartySize(booking.ScheduleId); // Should be one query

            if (partySize != booking.PartySize)
            {
                throw new NoReservationException(); 
            }

            var doesBookingExist = await _bookRepository.GetBooking(booking.ScheduleId) != 0;

            if (!doesBookingExist)
            {
                await _bookRepository.InsertBooking(booking.ScheduleId, totalTables);
            }

            await _bookRepository.UpdateBooking(booking, guest);
        }

        #region Validation

        private void ValidateBooking(Book booking)
        {
            // Skipping this but would check if date is in the past, etc. 

        }

        private void ValidateGuest(Book booking)
        {
            // skipping, i think i got this point across
        }

        #endregion
    }
}
