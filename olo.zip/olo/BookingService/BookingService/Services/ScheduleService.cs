﻿using BookingService.Exceptions;
using BookingService.Models;
using BookingService.Models.DataTransferObjects;
using BookingService.Repositories.Interfaces;
using BookingService.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Services
{
    public class ScheduleService : IScheduleService
    {
        private readonly IScheduleRepository _scheduleRepository;

        public ScheduleService(IScheduleRepository scheduleRepository)
        {
            _scheduleRepository = scheduleRepository;
        }

        public async Task CreateSchedule(Schedule schedule)
        {
            ValidateSchedule(schedule);

            // Edge case will be a double insert - this is also an issue because we don't have an update
            // If somehow two users for the same restaurant submitted a schedule at the same time, this would be an edge case. 
            // I would foresee maybe purging the DB on every insert, and inserting the entire schedule fresh but would depend on 
            // user flows, biz requirements. 
            await _scheduleRepository.InsertSchedule(schedule);
        }

        #region Validation

        private void ValidateSchedule(Schedule schedule)
        {
            if (schedule == null)
            {
                throw new ArgumentNullException(nameof(schedule));
            }

            if (schedule.RestaurantId < 0)
            {
                throw new ArgumentException($"{nameof(schedule.RestaurantId)} : {schedule.RestaurantId} was invalid", nameof(schedule.RestaurantId));
            }

            if (schedule.ScheduleDef == null)
            {
                throw new ArgumentNullException(nameof(schedule));
            }

            if (schedule.ScheduleDef.Count == 0)
            {
                throw new ArgumentException($"{nameof(schedule.ScheduleDef)} : {schedule.ScheduleDef} was invalid", nameof(schedule.ScheduleDef));
            }

            ValidateScheduleEntries(schedule.ScheduleDef);
        }

        private void ValidateScheduleEntries(List<ScheduleEntry> scheduleDef)
        {
            var times = new HashSet<string>();
            foreach (var entry in scheduleDef)
            {
                if (entry.Seats < 1)
                {
                    throw new ArgumentException($"{nameof(entry.Seats)} : {entry.Seats} was invalid", nameof(entry.Seats));
                }

                if (entry.Hour is < 1 or > 24)
                {
                    throw new ArgumentException($"{nameof(entry.Hour)} : {entry.Hour} was invalid", nameof(entry.Hour));
                }

                if ((entry.Minute is < 0 or > 45) || (entry.Minute != 0 && entry.Minute % 15 != 0))
                {
                    throw new ArgumentException($"{nameof(entry.Minute)} : {entry.Minute} was invalid", nameof(entry.Minute));
                }

                var time = $"{entry.Hour}:{entry.Minute}:{entry.Seats}";
                if (times.Contains(time))
                {
                    throw new ScheduleException();
                }
                else
                {
                    times.Add(time);
                }
            }
        }

        #endregion
    }
}
