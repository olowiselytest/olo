﻿using BookingService.Exceptions;
using BookingService.Models;
using BookingService.Repositories.Interfaces;
using BookingService.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace Services
{
    public class RestaurantService : IRestaurantService
    {
        private readonly IRestaurantRepository _restaurantRepository;

        public RestaurantService(IRestaurantRepository restaurantRepository)
        {
            _restaurantRepository = restaurantRepository;
        }

        public async Task<Restaurant> CreateRestaurant(Restaurant restaurant)
        {
            ValidateRestaurant(restaurant);

            var createdRestaurant = await _restaurantRepository.InsertRestaurant(restaurant);

            return createdRestaurant;
        }

        #region Validation 

        private void ValidateRestaurant(Restaurant restaurant)
        {
            if (restaurant.Name == null)
            {
                throw new ArgumentException($"{nameof(restaurant.Name)} was invalid", nameof(restaurant.Name));
            }
        }

        #endregion
    }
}
