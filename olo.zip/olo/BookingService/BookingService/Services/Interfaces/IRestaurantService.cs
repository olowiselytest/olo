﻿using BookingService.Models;
using System.Threading.Tasks;

namespace BookingService.Services.Interfaces
{
    public interface IRestaurantService
    {
        Task<Restaurant> CreateRestaurant(Restaurant restaurant);
    }
}
