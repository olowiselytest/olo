﻿using BookingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingService.Services.Interfaces
{
    public interface IBookService
    {
        Task CreateBooking(Book booking, Guest guest);
    }
}
