﻿using BookingService.Models;
using BookingService.Models.DataTransferObjects;
using System.Threading.Tasks;

namespace BookingService.Services.Interfaces
{
    public interface IScheduleService
    {
        Task CreateSchedule(Schedule schedule);
    }
}
