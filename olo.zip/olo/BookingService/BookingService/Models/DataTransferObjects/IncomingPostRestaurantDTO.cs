﻿namespace BookingService.Models.DataTransferObjects
{
    public record IncomingPostRestaurantDTO 
    {
        public string Name { get; set; }
    }
}
