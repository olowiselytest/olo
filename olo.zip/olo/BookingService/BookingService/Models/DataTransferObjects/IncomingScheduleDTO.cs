﻿using System.Collections.Generic;

namespace BookingService.Models.DataTransferObjects
{
    public class IncomingScheduleDTO
    {
        public int RestaurantId { get; set; }

        public List<IncomingScheduleEntryDTO> ScheduleDef { get; set; }
    }
}
