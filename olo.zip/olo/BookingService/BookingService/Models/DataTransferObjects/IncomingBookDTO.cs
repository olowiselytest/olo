﻿using System;

namespace BookingService.Models.DataTransferObjects
{
    public class IncomingBookDTO
    {
        public string Name { get; set; }

        public int ScheduleId { get; set; } // THIS IS A SHORT CUT rather than parsing date/time

        public string Email { get; set; }

        public int PartySize { get; set; }

        public DateTime Date { get; set; }

        public string Time { get; set; }
    }
}
