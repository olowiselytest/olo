﻿namespace BookingService.Models.DataTransferObjects
{
    public class OutgoingRestaurantDTO
    {
        public int RestaurantId { get; set; }
        public string Name { get; set; }
    }
}
