﻿namespace BookingService.Models.DataTransferObjects
{
    public class IncomingScheduleEntryDTO
    {
        public int Seats { get; set; }
        public int NumberOfTables { get; set; }
        public int Hour { get; set; } // counting 0-23 ignoring time zones, though it could be an issue.
        public int Minute { get; set; }
    }
}