﻿namespace BookingService.Models
{
    public class ErrorDetails
    {
        public string Message { get; set; }
        public int Code { get; set; }
    }
}
