﻿using System.Collections.Generic;

namespace BookingService.Models
{
    public class Schedule
    {
        public int RestaurantId { get; set; }

        public List<ScheduleEntry> ScheduleDef { get; set; }
    }
}
