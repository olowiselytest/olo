﻿namespace BookingService.Models
{
    public class ScheduleEntry
    {
        public int RestaurantId {get; set;}

        public int ScheduleId {get; set;}

        public int Seats { get; set; }

        public int NumberOfTables { get; set; }

        public int Hour { get; set; }

        public int Minute { get; set; }

        public string Time => $"{Hour}:{Minute}";
    }
}
