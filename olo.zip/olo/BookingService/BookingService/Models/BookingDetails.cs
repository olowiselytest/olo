﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookingService.Models
{
    public class BookingDetails
    {
        public int BookingId { get; set; }

        public int ScheduleId { get; set; }

        public int TotalTables { get; set; }

        public int TakenTables { get; set; }
    }
}
