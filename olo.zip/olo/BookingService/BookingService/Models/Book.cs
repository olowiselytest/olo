﻿using System;

namespace BookingService.Models
{
    public class Book
    {
        public int PartySize { get; set; }

        public int ScheduleId { get; set; }

        public DateTime Date { get; set; }

        public string Time { get; set; }
    }
}
